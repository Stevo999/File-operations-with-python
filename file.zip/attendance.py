#Question a #
def csc_217_attendance():
	file=open("CSC_217_attendance_ week1_30.txt","r")#opens file in read mode#
	a=file.read()#read the content of the file#
	file.close()
	file=open("CSC_217_attendance_ week1_end.txt","r")#opens teh file in read mode#
	b=file.read()#reads the comtemt of the file#
	file.close()
	c=a+b#add the content of the two files and place it in a variable c#
	d=set()
	file=open("csc_217_attendance.txt","w")#opens the file in write mode#
	for i in c:
		file.write(i)
	file.close()
	file=open("csc_217_attendance_week1.txt","w")
	for i in open("csc_217_attendance.txt","r"):
		if i not in d:
			file.write(i)#write the content of the two files in the file named cac_217_attendance.txt#
			d.add(i)
	file.close
csc_217_attendance()

#Question b #
import csc_217_attendance
def csc_217_separated():
    file=open("csc_217_attendance_week1.txt","r")#opens the file in read mode#
    read_names=[i for i in file]#read the content of the file#
    file=open("csc_217_computer.txt","w")#opens the file in write mode#
    for i in read_names:
            if "B135" in i:
                file.write(i)#write name in csc_217_computer.txt if "B135" is in the name#
    file.close()#close the file#
    file=open("csc_217_IT.txt","w")#open the file in read mode#
    for i in read_names:
        if "B141" in i:
            file.write(i)#write name if "B141" is in the name#
    file.close()
    file.close()
csc_217_separated()

#Question c #
def csc_217_computer():
	file=open("csc_217_computer.txt","r")
	file2=open("csc_217_computer_formatted.txt","w")
	f=[i for i in file]
	for i in f:
		if "B135" in i:
			t=i.split()
			for i in t:
				if "B135" in i:
					index=t.index(i)
					t=[t[index]]+t[:index]+t[index+1:]
		h=(" ".join(t))
		file2.write(h+"\n")
	file2.close()
	file.close()
	file=open("csc_217_computer_formatted.txt","r")
	k=[file.read()]
	for i in k:
		s=i.replace("-"," ")
	file.close()
	file2=open("csc_217_computer_formatted_final.txt","w")
	for i in s:
		file2.write(i)
	file2.close()
	file = open("csc_217_computer_formatted_final.txt", "r")
	k = [file.read()]
	for i in k:
		if "B135" in i:
			s=i.replace("2019","2019 ")
	file.close()
	file2 = open("csc_217_computer_formatted_final.txt", "w")
	for i in s:
		file2.write(i)
	file2.close()
	file = open("csc_217_computer_formatted_final.txt","r")
	k = [file.read()]
	for i in k:
		l = i.replace("  "," ")
	file2=open("csc_217_computer_formatted_final.txt","w")
	for i in l:
		file2.write(i)
	file2.close()
	file = open("csc_217_computer_formatted_final.txt","r")
	k = [file.read()]
	for i in k:
		l = i.replace(" ","_")
	file2=open("csc_217_computer_formatted_final.txt","w")
	for i in l:
		file2.write(i)
	file2.close()
csc_217_computer()

def csc_217_IT():
	file = open("csc_217_IT.txt","r")
	file2 = open("csc_217_IT_formatted.txt","w")
	f = [i for i in file]
	for i in f:
		if "B141" in i:
			g = i.split()
			for i in g:
				if "B141" in i:
					index = g.index(i)
					g = [g[index]] + g[:index] + g[index + 1:]
		h = (" ".join(g))
		file2.write(h + "\n")
	file2.close()
	file = open("csc_217_IT_formatted.txt","r")
	k = [file.read()]
	for i in k:
		if "B141" in i:
			l=i.replace("2019","2019 ")
	file.close()
	file2 = open("csc_217_IT_formatted_final.txt","w")
	for i in l:
		file2.write(i)
	file2.close()
	file = open("csc_217_IT_formatted_final.txt", "r")
	k = [file.read()]
	for i in k:
		if "B141" in i:
			l = i.replace("-", "")
	file.close()
	file2 = open("csc_217_IT_formatted_final.txt", "w")
	for i in l:
		file2.write(i)
	file2.close()
	file = open("csc_217_IT_formatted_final.txt", "r")
	k = [file.read()]
	for i in k:
		if "B141" in i:
			l = i.replace("  ", " ")
	file.close()
	file2 = open("csc_217_IT_formatted_final.txt", "w")
	for i in l:
		file2.write(i)
	file2.close()
	file = open("csc_217_IT_formatted_final.txt", "r")
	k = [file.read()]
	for i in k:
		if "B141" in i:
			l = i.replace("_", "")
	file.close()
	file2 = open("csc_217_IT_formatted_final.txt", "w")
	for i in l:
		file2.write(i)
	file2.close()
	file = open("csc_217_IT_formatted_final.txt","r")
	k = [file.read()]
	for i in k:
		if "B141" in i:
			l = i.replace(" ","_")
	file.close()
	file2 = open("csc_217_IT_formatted_final.txt", "w")
	for i in l:
		file2.write(i)
	file2.close()
csc_217_IT()

#Question d #
def csc_217_formated():
    #for computer science students#
    file=open("csc_217_computer_formatted_final.txt","r")
    d=[file.read()]
    for i in d:
        e=i.replace("2019_","2019, ")
    file.close()
    file=open("csc_217_computer_week1.txt","w")
    for i in e:
        file.write(i)
    file.close()
    file = open("csc_217_computer_week1.txt", "r")
    d = [file.read()]
    for i in d:
        e = i.replace("2018_", "2018, ")
    file.close()
    file = open("csc_217_computer_week1.txt", "w")
    for i in e:
        file.write(i)
    file.close()
    file = open("csc_217_computer_week1.txt", "r")
    d = [file.read()]
    for i in d:
        e = i.replace("2016_", "2016, ")
    file.close()
    file = open("csc_217_computer_week1.txt", "w")
    for i in e:
        file.write(i)
    file.close()
    file = open("csc_217_computer_week1.txt", "r")
    d = [file.read()]
    for i in d:
        e = i.replace("_", " ")
    file.close()
    file = open("csc_217_computer_week1.txt", "w")
    for i in e:
        file.write(i)
    file.close()
    file = open("csc_217_computer_week1.txt", "r")
    d = [file.read()]
    for i in d:
        e = i.replace("17838/2019", "17838/2019 computer 2019")
    file.close()
    file = open("csc_217_computer_week1.txt", "w")
    for i in e:
        file.write(i)
    file.close()

    #for IT students#
    file = open("csc_217_IT_formatted_final.txt", "r")
    d = [file.read()]
    for i in d:
        e = i.replace("2019_", "2019, ")
    file.close()
    file = open("csc_217_IT_week1.txt", "w")
    for i in e:
        file.write(i)
    file.close()
    file = open("csc_217_IT_week1.txt", "r")
    d = [file.read()]
    for i in d:
        e = i.replace(" _", " ")
    file.close()
    file = open("csc_217_IT_week1.txt", "w")
    for i in e:
        file.write(i)
    file.close()
    file = open("csc_217_IT_week1.txt", "r")
    d = [file.read()]
    for i in d:
        e = i.replace("_", " ")
    file.close()
    file = open("csc_217_IT_week1.txt", "w")
    for i in e:
        file.write(i)
    file.close()
csc_217_formated()
